library(testthat)
library(nucleR)

test_check("nucleR")
